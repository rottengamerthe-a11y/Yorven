import React, { useEffect, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Link, NavLink, Route, Routes, useLocation } from 'react-router-dom'
import { ArrowDownRight, ArrowUpRight, Check, Code2, Layers3, Menu, X, Zap } from 'lucide-react'
import './styles.css'

const services = [
  { icon: Code2, number: '01', title: 'Websites', text: 'Fast, expressive sites that make a sharp first impression and turn attention into momentum.', tags: ['Strategy', 'Design systems', 'Development'] },
  { icon: Layers3, number: '02', title: 'Digital products', text: 'Web and mobile applications shaped around the people who use them and the business behind them.', tags: ['Product thinking', 'UX/UI', 'Engineering'] },
  { icon: Zap, number: '03', title: 'Systems & scale', text: 'The quiet, dependable infrastructure that connects teams, tools and ambitious ideas.', tags: ['SaaS', 'Automation', 'APIs'] }
]

const work = [
  { label: 'Concept project', title: 'Northstar', type: 'Product strategy · SaaS', className: 'work-northstar', description: 'A calmer operating system for modern teams.' },
  { label: 'Concept project', title: 'Lumen', type: 'Mobile experience · Fintech', className: 'work-lumen', description: 'Making the everyday money decision feel simple.' },
  { label: 'Concept project', title: 'Arc / 01', type: 'Brand platform · Culture', className: 'work-arc', description: 'A digital home for a new kind of collective.' }
]
const heroWords = ['Your', 'next', 'big', 'idea', 'deserves', 'better', 'engineering']

function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [pathname])
  return null
}

function useScrollMotion() {
  useEffect(() => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const root = document.documentElement
    root.classList.add('motion-ready')
    root.classList.toggle('motion-reduced', reduced)
    const revealObserver = reduced ? null : new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible')
          revealObserver.unobserve(entry.target)
        }
      })
    }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' })
    document.querySelectorAll('.scroll-reveal, .stagger-reveal, .process-grid').forEach((element) => {
      if (revealObserver) revealObserver.observe(element)
      else element.classList.add('is-visible')
    })
    const onScroll = () => root.classList.toggle('nav-scrolled', window.scrollY > 24)
    const onPointerMove = (event) => {
      const art = event.currentTarget
      art.style.setProperty('--pointer-x', `${(event.clientX / window.innerWidth - 0.5) * 2}`)
      art.style.setProperty('--pointer-y', `${(event.clientY / window.innerHeight - 0.5) * 2}`)
    }
    const onPointerLeave = (event) => {
      event.currentTarget.style.setProperty('--pointer-x', '0')
      event.currentTarget.style.setProperty('--pointer-y', '0')
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    const heroArt = document.querySelector('.hero-art')
    if (heroArt && !reduced) {
      heroArt.addEventListener('pointermove', onPointerMove)
      heroArt.addEventListener('pointerleave', onPointerLeave)
    }
    onScroll()
    return () => {
      revealObserver?.disconnect()
      window.removeEventListener('scroll', onScroll)
      heroArt?.removeEventListener('pointermove', onPointerMove)
      heroArt?.removeEventListener('pointerleave', onPointerLeave)
      root.classList.remove('motion-ready', 'motion-reduced', 'nav-scrolled')
    }
  }, [])
}

function Layout({ children }) {
  const [open, setOpen] = useState(false)
  const close = () => setOpen(false)
  return <>
    <div className="scroll-progress" aria-hidden="true" />
    <header className="nav-wrap">
      <nav className="nav container">
        <Link className="logo" to="/" onClick={close}><img src="/yorven-logo.png" alt="Yorven" /></Link>
        <div className={`nav-links ${open ? 'is-open' : ''}`}>
          <NavLink to="/#services" onClick={close}>Services</NavLink>
          <NavLink to="/work" onClick={close}>Work</NavLink>
          <NavLink to="/about" onClick={close}>About</NavLink>
          <NavLink className="nav-contact" to="/contact" onClick={close}>Start a project <ArrowUpRight size={15} /></NavLink>
        </div>
        <button className="menu-button" aria-label="Toggle menu" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
      </nav>
    </header>
    <main>{children}</main>
    <Footer />
  </>
}

function Footer() {
  return <footer className="footer">
    <div className="container footer-grid">
      <div><Link className="logo" to="/"><img src="/yorven-logo.png" alt="Yorven" /></Link><p className="footer-note">Thoughtful digital products<br />for what's next.</p></div>
      <div><p className="eyebrow">Explore</p><Link to="/#services">Services</Link><Link to="/work">Work</Link><Link to="/about">About</Link><Link to="/contact">Contact</Link></div>
      <div><p className="eyebrow">Get in touch</p><a href="mailto:hello@yorven.com">hello@yorven.com</a><span>WhatsApp available on request</span></div>
      <div><p className="eyebrow">Elsewhere</p><span>LinkedIn <small>↗</small></span><span>Instagram <small>↗</small></span></div>
    </div>
    <div className="container footer-bottom"><span>© {new Date().getFullYear()} Yorven Technologies</span><div><Link to="/privacy">Privacy</Link><Link to="/terms">Terms</Link></div></div>
  </footer>
}

function Home() {
  const [active, setActive] = useState(0)
  useScrollMotion()
  return <div>
    <section className="hero container scroll-reveal is-visible">
      <div className="hero-copy reveal"><h1 aria-label="Your next big idea deserves better engineering">{heroWords.map((word, index) => <React.Fragment key={word}>{word === 'deserves' ? <em className="hero-word" style={{ '--word-index': index }}>{word}</em> : <span className="hero-word" style={{ '--word-index': index }}>{word}</span>}{word === 'idea' || word === 'deserves' ? ' ' : ' '}</React.Fragment>)}<span className="lime">.</span></h1><p className="lede">We design and develop websites, applications and digital products that help businesses move forward.</p><div className="hero-actions"><Link className="button button-lime" to="/contact">Start a project <ArrowUpRight size={17} /></Link><Link className="text-link" to="/work">Explore our work <ArrowDownRight size={17} /></Link></div></div>
      <div className="hero-art reveal" aria-label="Yorven product studio visual">
        <div className="hero-canvas-grid" aria-hidden="true" />
        <div className="hero-signal"><span className="hero-logo-mark" aria-label="Yorven" /><i /><i /><i /></div>
        <div className="hero-orbit orbit-a" aria-hidden="true" />
        <div className="hero-orbit orbit-b" aria-hidden="true" />
        <div className="hero-panel panel-focus"><span className="panel-index">01 / FOCUS</span><strong>Thoughtful<br /><em>systems.</em></strong><div className="panel-line" /><small>Built to make complexity feel clear.</small></div>
        <div className="hero-panel panel-signal"><span className="panel-index">02 / SIGNAL</span><strong>Signal<br /><em>in motion.</em></strong><div className="panel-bars"><i /><i /><i /><i /><i /></div></div>
        <div className="hero-panel panel-approach"><span className="panel-index">03 / APPROACH</span><strong>Move<br /><em>with intent.</em></strong><div className="panel-line" /><small>From first question to final detail.</small></div>
      </div>
      <div className="hero-scroll"><span>Scroll to explore</span><div className="scroll-line" /></div>
    </section>
    <div className="brand-marquee" aria-label="Yorven capabilities"><div><span>Strategy</span><b className="marquee-spark" aria-hidden="true" /><span>Design</span><b className="marquee-spark" aria-hidden="true" /><span>Engineering</span><b className="marquee-spark" aria-hidden="true" /><span>Websites</span><b className="marquee-spark" aria-hidden="true" /><span>Apps</span><b className="marquee-spark" aria-hidden="true" /><span>Strategy</span><b className="marquee-spark" aria-hidden="true" /><span>Design</span><b className="marquee-spark" aria-hidden="true" /></div></div>
    <section className="manifesto section container scroll-reveal"><div className="section-rule" /><div className="manifesto-grid"><p className="eyebrow">The Yorven approach</p><div><h2>More than development.<br /><span>A technology partner.</span></h2><p className="body-copy">The best digital products live at the intersection of a clear idea, a considered experience and solid engineering. We bring all three to the table — without the layers, jargon or hand-offs.</p><Link className="text-link" to="/about">How we work <ArrowUpRight size={16} /></Link></div></div><div className="brand-strip"><img src="/yorven-logo.png" loading="lazy" alt="Yorven logo on its signature gradient" /><div><p className="eyebrow">Our visual language</p><p>Deep waters. New growth. A little light at the edge.</p></div></div></section>
    <section id="services" className="section services-section scroll-reveal"><div className="container"><div className="section-heading"><div><h2>Built around<br /><span>your ambition.</span></h2></div><p className="section-intro">From the first sketch to the final pixel, we help good ideas become useful, beautiful and resilient digital products.</p></div><div className="service-list">{services.map((service, i) => { const Icon = service.icon; return <article className={`service-row stagger-reveal ${active === i ? 'active' : ''}`} onMouseEnter={() => setActive(i)} onClick={() => setActive(i)} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); setActive(i) } }} tabIndex="0" aria-pressed={active === i} key={service.number}><span className="service-number">{service.number}</span><Icon className="service-icon" size={27} strokeWidth={1.5} /><div className="service-main"><h3>{service.title}</h3><p>{service.text}</p></div><div className="service-tags">{service.tags.map(tag => <span key={tag}>{tag}</span>)}</div><ArrowUpRight className="row-arrow" size={22} /></article> })}</div></div></section>
    <section className="work-section section container scroll-reveal"><div className="section-heading"><div><h2>A few things<br /><span>we've imagined.</span></h2></div><Link className="text-link" to="/work">View all work <ArrowUpRight size={16} /></Link></div><div className="work-grid">{work.map(item => <WorkCard key={item.title} item={item} />)}</div></section>
    <Process />
    <section className="final-cta container scroll-reveal"><div className="cta-grid"><p className="eyebrow">Have something worth building?</p><div><h2>Let's make it<br /><em>real.</em><span className="lime">↗</span></h2><p className="body-copy">Tell us what you're working on. We’ll bring curiosity, clarity and craft to the table.</p><Link className="button button-lime" to="/contact">Start a conversation <ArrowUpRight size={17} /></Link></div></div></section>
  </div>
}

function WorkCard({ item }) {
  return <Link className="work-card parallax-card" to="/work"><div className={`work-visual ${item.className}`}><div className="visual-top"><span>{item.label}</span><span>↗</span></div><div className="visual-content">{item.title === 'Northstar' ? <><div className="mini-chart"><i /><i /><i /><i /><i /><i /></div><strong>Good morning,<br />Maya.</strong></> : item.title === 'Lumen' ? <><div className="phone"><b>$ 4,820.00</b><span>Available balance</span><div className="phone-line" /></div><div className="coin">✦</div></> : <div className="arc-shape"><span>arc</span></div>}</div></div><div className="work-meta"><div><h3>{item.title}</h3><p>{item.type}</p></div><span className="work-arrow"><ArrowUpRight size={18} /></span></div></Link>
}

function Process() {
  const items = [['01', 'Discover', 'Understand the business, the users and the opportunity.'], ['02', 'Define', 'Turn the messy middle into a clear, shared direction.'], ['03', 'Design', 'Make the experience feel as good as the idea behind it.'], ['04', 'Develop', 'Build the dependable, maintainable product underneath.'], ['05', 'Refine', 'Test, learn and make every detail earn its place.'], ['06', 'Launch', 'Ship with confidence and keep improving together.']]
  return <section className="process-section section scroll-reveal"><div className="container"><div className="section-heading"><div><p className="eyebrow">A considered process</p><h2>From first thought<br /><span>to final launch.</span></h2></div><p className="section-intro">The path from an idea to a product is rarely a straight line. Our job is to make the next step feel clear.</p></div><div className="process-grid">{items.map(([num, title, text]) => <div className="process-item stagger-reveal" key={num}><span>{num}</span><h3>{title}</h3><p>{text}</p></div>)}</div></div></section>
}

function Work() { return <PageShell eyebrow="Selected work" title={<>Ideas with<br /><span>somewhere to go.</span></>}><p className="page-intro">A selection of concept projects that show how we think, design and build. The work below is fictional and created to demonstrate our approach.</p><div className="work-grid work-page-grid">{work.map(item => <WorkCard key={item.title} item={item} />)}</div></PageShell> }
function About() { return <PageShell eyebrow="A little about us" title={<>Good work starts<br /><span>with good questions.</span></>}><div className="about-layout"><div><p className="page-intro">Yorven is an independent digital product studio for businesses with something meaningful to build.</p><p className="body-copy">We believe technology should make things clearer, not more complicated. That means asking the right questions early, sweating the details and building with enough care that the product can keep up with the people using it.</p></div><div className="principles">{[['01','Clarity over theatre'],['02','Craft in every layer'],['03','Progress, together']].map(([n,t]) => <div key={n}><span>{n}</span><h3>{t}</h3><p>Thoughtful decisions, made visible and shared along the way.</p></div>)}</div></div></PageShell> }
function PageShell({ eyebrow, title, children }) { return <section className="page-shell container"><p className="eyebrow">{eyebrow}</p><h1>{title}<span className="lime">.</span></h1>{children}</section> }
function Contact() {
  const [sent, setSent] = useState(false)
  const [error, setError] = useState('')
  const [sending, setSending] = useState(false)
  async function submit(e) {
    e.preventDefault()
    const form = e.currentTarget
    const data = new FormData(form)
    if (!data.get('name') || !data.get('email') || !data.get('description')) { setError('Please complete your name, email and project description.'); return }
    const endpoint = import.meta.env.VITE_CONTACT_ENDPOINT
    if (!endpoint) { setError('This form is not connected yet. Please email hello@yorven.com while the enquiry endpoint is being configured.'); return }
    setError('')
    setSending(true)
    try {
      const response = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.fromEntries(data)) })
      if (!response.ok) throw new Error(`Contact endpoint returned ${response.status}`)
      setSent(true)
      form.reset()
    } catch (submissionError) {
      console.error(submissionError)
      setError('We couldn’t send your enquiry. Please email hello@yorven.com instead.')
    } finally { setSending(false) }
  }
  return <PageShell eyebrow="Start a conversation" title={<>Let's build<br /><span>what's next.</span></>}><div className="contact-layout"><div><p className="page-intro">Have a project in mind, or just a question? Give us the shape of the idea and we’ll take it from there.</p><div className="contact-detail"><p className="eyebrow">Email</p><a href="mailto:hello@yorven.com">hello@yorven.com <ArrowUpRight size={15} /></a></div><div className="contact-detail"><p className="eyebrow">WhatsApp</p><p>Available once a business number is configured.</p></div></div><div className="form-card">{sent ? <div className="success"><div className="success-icon"><Check /></div><h2>Thanks for reaching out.</h2><p>Your enquiry has been sent. We’ll be in touch soon.</p></div> : <form onSubmit={submit}><div className="form-grid"><label>Full name<input name="name" placeholder="Your name" /></label><label>Business name<input name="business" placeholder="Company or team" /></label><label>Email address<input name="email" type="email" placeholder="you@company.com" /></label><label>Project type<select name="type" defaultValue=""><option value="" disabled>Select one</option><option>Website</option><option>Web application</option><option>Mobile application</option><option>Something else</option></select></label><label className="full">Project description<textarea name="description" rows="5" placeholder="Tell us what you're thinking about..." /></label></div>{error && <p className="form-error">{error}</p>}<button className="button button-lime" type="submit" disabled={sending}>{sending ? 'Sending…' : 'Send enquiry'} {!sending && <ArrowUpRight size={17} />}</button><p className="form-footnote">We’ll only use your details to respond to this enquiry.</p></form>}</div></div></PageShell>
}
function Legal({ title, children }) { return <PageShell eyebrow="Yorven Technologies" title={<>{title}<span className="lime">.</span></>}>{children}</PageShell> }
function App() { return <BrowserRouter><ScrollToTop /><Layout><Routes><Route path="/" element={<Home />} /><Route path="/work" element={<Work />} /><Route path="/about" element={<About />} /><Route path="/contact" element={<Contact />} /><Route path="/privacy" element={<Legal title="Privacy policy">{<p className="legal-copy">This page will contain Yorven’s complete privacy policy before launch. We only collect information you choose to share with us, and use it to respond to your enquiry and provide requested services.</p>}</Legal>} /><Route path="/terms" element={<Legal title="Terms of use">{<p className="legal-copy">This page will contain Yorven’s terms of use before launch. Please contact us if you need a copy of the current terms for review.</p>}</Legal>} /><Route path="*" element={<PageShell eyebrow="404" title={<>That page went<br /><span>somewhere else.</span></>}><Link className="button button-lime" to="/">Back home <ArrowUpRight size={17} /></Link></PageShell>} /></Routes></Layout></BrowserRouter> }

createRoot(document.getElementById('root')).render(<React.StrictMode><App /></React.StrictMode>)
